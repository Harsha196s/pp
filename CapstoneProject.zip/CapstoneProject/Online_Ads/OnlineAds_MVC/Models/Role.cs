﻿using System.ComponentModel.DataAnnotations;

namespace Online_AdsWebApi.Models
{
    public class Role
    {
        [Key]

        public int RoleId { get; set; }

        public string RoleName { get; set; }
    }
}
