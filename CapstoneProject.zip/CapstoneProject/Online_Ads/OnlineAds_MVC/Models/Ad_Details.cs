﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Online_AdsWebApi.Models
{
    public class Ad_Details
    {
        [ForeignKey("AdID")]

        public int AdID { get; set; }

        // public int CategoryID { get; set; }

        public string MainCategory { get; set; }

        public string SubCategory { get; set; }

        public string FullName { get; set; }

        public string EmailID { get; set; }

        public long PhoneNo { get; set; }

        public DateTime Created { get; set; }

        //public DateTime Adsstartdate { get; set; }

        public string status { get; set; }

        //public DateTime AdsEndDate { get; set; }

        public string Title { get; set; }

        public string Description { get; set; }
       
        public int UserID { get; set; }

    }



}

