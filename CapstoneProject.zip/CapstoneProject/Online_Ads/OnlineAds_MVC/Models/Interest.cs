﻿using System.ComponentModel.DataAnnotations;

namespace Online_AdsWebApi.Models
{
    public class Interest
    {
        [Key]

        public int InterestID { get; set; }

        public int AdID { get; set; }

        public string fullName { get; set; }

        public DateTime Created { get; set; }
    }
}
