﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Online_AdsWebApi.Models
{
    public class CategoryViewModel
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CategoryID { get; set; }

        public string CategoryType { get; set; }

        public string CategoryName { get; set; }

        public DateTime Created { get; set; }
    }
}
