﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Online_AdsWebApi.Models
{
    public class User
    {
        [Key]

        public int UserID { get; set; }
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [Required]
        public string FullName { get; set; }
        [Required]
        public DateTime DOB { get; set; }
        [Required]
        public string Gender { get; set; }
        [Required]
        public string State { get; set; }
        [Required]
       
        public string EmailID { get; set; }
        [Required]
        public long PhoneNo { get; set; }
        [ForeignKey("RoleId")]
        public int RoleId { get; set; }

       

       

    }
}
