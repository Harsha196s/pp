﻿using Microsoft.EntityFrameworkCore;

namespace Online_AdsWebApi.Models
{
    public class AppDbContext : DbContext

    {

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)

        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)

            {

            //    modelBuilder.HasSequence("CustSequence").StartsAt(1000).IncrementsBy(1);

            //    modelBuilder.Entity<User>().Property(x => x.UserID).HasDefaultValueSql("NEXT VALUE FOR CustSequence");

            //    base.OnModelCreating(modelBuilder);

            //modelBuilder.HasSequence("AdSequence").StartsAt(1).IncrementsBy(1);

            //modelBuilder.Entity<Ad_Details>().Property(x => x.AdID).HasDefaultValueSql("NEXT VALUE FOR AdSequence");

            //base.OnModelCreating(modelBuilder);

        }

            //protected override void OnModelCreating(ModelBuilder modelBuilder)

            //{

            // modelBuilder.Entity<Roles>().HasData(

            // new Roles { RoleID = 1, RoleName = "Admin" },

            // new Roles { RoleID = 2, RoleName = "User" }

            // );

            // base.OnModelCreating(modelBuilder);

            //}

            public virtual DbSet<User> Users { get; set; }

            public virtual DbSet<Role> Roles { get; set; }

            public virtual DbSet<CategoryViewModel> Categories { get; set; }

            public virtual DbSet<Ad_Details> Ad_Details { get; set; }

            public virtual DbSet<Interest> Interests { get; set; }

        }
    }

