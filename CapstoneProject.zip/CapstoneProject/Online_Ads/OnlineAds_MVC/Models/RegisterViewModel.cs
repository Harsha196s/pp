﻿using System.ComponentModel.DataAnnotations;

namespace Online_AdsWebApi.Models
{
    public class RegisterViewModel
    {

        public int UserID { get; set; }
        public string Password { get; set; }

        [Compare("Password", ErrorMessage = "Password doesn't match")]

        public string ConfirmPassword { get; set; }

        public string FullName { get; set; }

        public DateTime DOB { get; set; }

        public string Gender { get; set; }

        public string State { get; set; }

        public string EmailID { get; set; }

        public long PhoneNo { get; set; }
        public int RoleId { get; set; }
    }
}
