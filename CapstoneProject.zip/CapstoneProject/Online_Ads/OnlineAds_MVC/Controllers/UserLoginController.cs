﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Online_AdsWebApi.Models;

namespace OnlineAds_MVC.Controllers
{
    public class UserLoginController : Controller
    {
        [BindProperty]

        public LoginViewModel LoginUser { get; set; }

        [BindProperty]

        public RegisterViewModel RegisterUser { get; set; }

        public IActionResult Index()

        {

            return View();

        }

        public IActionResult Register()

        {

            return View();

        }

        public IActionResult RegisterSuccess()

        {

            return View();

        }

        [HttpPost]

        public IActionResult Register(RegisterViewModel rm)

        {

            if (ModelState.IsValid)

            {

                using (var httpClient = new HttpClient())

                {

                    StringContent content = new StringContent(JsonConvert.SerializeObject(RegisterUser), Encoding.UTF8, "application/json");

                    using (var response = httpClient.PostAsync("http://localhost:34350/Login/RegisterUser", content))

                    {

                        if (response.Result.IsSuccessStatusCode)

                        {

                            //var responseText = response.Result.Content.ReadAsStringAsync().Result;

                            return RedirectToAction("RegisterSuccess");

                        }

                        else

                        {

                            ViewData["Message"] = "Invalid Registration";

                        }

                    }

                }

            }

            return View();

        }

        public IActionResult Login()

        {

            return View();

        }

        public IActionResult LoginSuccess(string m)

        {

            // return View();

            ViewData["Message"] = m;

            return View();

        }

        //public IActionResult LoginSuccess()

        //{

        // return View();

        //}

        [HttpPost]

        public IActionResult Login(LoginViewModel lm)

        {

            if (ModelState.IsValid)

            {

                using (var httpClient = new HttpClient())

                {

                    StringContent content = new StringContent(JsonConvert.SerializeObject(LoginUser), Encoding.UTF8, "application/json");

                    using (var response = httpClient.PostAsync("http://localhost:34550/Login/LoginUser", content))

                    {

                        if (response.Result.IsSuccessStatusCode)

                        {

                            var responseText = response.Result.Content.ReadAsStringAsync().Result;

                            //ViewData["Message"] = "Valid Login Credentials";

                            return RedirectToAction("LoginSuccess", new { m = responseText });

                        }

                        else

                        {

                            ViewData["Message"] = "Check the details";

                            return RedirectToAction("Index");

                        }

                    }

                }

            }

            //return View("LoginSuccess", ViewData["Message"]);

            return View();

        }

    }

}

    