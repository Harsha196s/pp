﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Online_AdsWebApi.Models;
using System.Text;

namespace OnlineAds_MVC.Controllers
{
    public class AdminController : Controller
    {
        [BindProperty]

        public LoginViewModel Admin { get; set; }
        [BindProperty]

        public Ad_Details adsDetails { get; set; }
        [BindProperty]

        public CategoryViewModel ctdetails { get; set; }

        public async Task<IActionResult> CategoryList()

        {

           

            List<CategoryViewModel> CAT = new List<CategoryViewModel>();

            using (var httpClient = new HttpClient())

            {

                using (var response = await httpClient.GetAsync("http://localhost:33050/Admin/ManagersList"))

                {

                    var apiResponse = await response.Content.ReadAsStringAsync();

                    CAT = JsonConvert.DeserializeObject<List<CategoryViewModel>>(apiResponse);

                }

            }

            return View(CAT);

        }
        public IActionResult AddCategory()

        {

            return View();

        }

        public IActionResult Categoryadded()
       

        {

           

            return View();

        }
        [HttpPost]

        public IActionResult AddCategory(CategoryViewModel ctDetails)

        {

            

            if (ModelState.IsValid)

            {

                using (var httpClient = new HttpClient())

                {

                    StringContent content = new StringContent(JsonConvert.SerializeObject(ctdetails), Encoding.UTF8, "application/json");

                    using (var response = httpClient.PostAsync("http://localhost:33050/Admin/AddManager", content))

                    {

                        if (response.Result.IsSuccessStatusCode)

                        {

                            var responseText = response.Result.Content.ReadAsStringAsync().Result;

                            return RedirectToAction("Categoryadded", new { m = responseText });

                        }

                        else

                        {

                            ViewData["Message"] = "Not Added To The List";

                        }

                    }

                }

            }

            return View();

        }
        public IActionResult ModifyCategory()

        {

            return View();

        }

        public IActionResult CategoryModified()


        {

           

            return View();

        }
        [HttpPost]

        public async Task<IActionResult> ModifyCategory(int id)

        {

            if (ModelState.IsValid)

            {

                using (var httpClient = new HttpClient())

                {

                    StringContent content = new StringContent(JsonConvert.SerializeObject(ctdetails), Encoding.UTF8, "application/json");

                    using (var response = await httpClient.PostAsync("http://localhost:33050/Admin/" + id, content))

                    {

                        if (response.IsSuccessStatusCode)

                        {

                            var responseText = response.Content.ReadAsStringAsync().Result;

                            return RedirectToAction("CategoryModified", new { m = responseText });

                        }

                        else

                        {

                            ViewData["Message"] = "Not Added To The List";

                        }

                    }

                }

            }

            return View();

            

        }
        public IActionResult StatusChanged(string m)

        {

         

            return View();

        }

        public IActionResult ModifyStatus()

        {

            return View();

        }

        [HttpPost]

        public async Task<IActionResult> ModifyStatus(int id)

        {

            if (!ModelState.IsValid)

            {

                using (var httpClient = new HttpClient())

                {

                    StringContent content = new StringContent(JsonConvert.SerializeObject(adsDetails), Encoding.UTF8, "application/json");

                    using (var response = await httpClient.PostAsync("http://localhost:33050/BankManager/" + id, content))

                    {

                        if (response.IsSuccessStatusCode)

                        {

                            var responseText = response.Content.ReadAsStringAsync().Result;

                            return RedirectToAction("StatusChanged", new { m = responseText });

                        }

                        else

                        {

                            ViewData["Message"] = "Not Added To The List";

                        }

                    }

                }

            }

            

            return View();

        }

        public IActionResult DelCategory()

        {

            return View();

        }

        public IActionResult Delcategory()


        {


            return View();

        }
        [HttpPost]

        public async Task<IActionResult> DelCategory(int id)

        {

            if (ModelState.IsValid)

            {

                using (var httpClient = new HttpClient())

                {

                    StringContent content = new StringContent(JsonConvert.SerializeObject(ctdetails), Encoding.UTF8, "application/json");

                    using (var response = await httpClient.PostAsync("http://localhost:33050/Admin/" + id, content))

                    {

                        if (response.IsSuccessStatusCode)

                        {

                            var responseText = response.Content.ReadAsStringAsync().Result;

                            return RedirectToAction("Delcategory", new { m = responseText });

                        }

                        else

                        {

                            ViewData["Message"] = "Not Added To The List";

                        }

                    }

                }

            }

            return View();
        }
        public async Task<IActionResult> ViewCategory()

        {

            List<CategoryViewModel> cat = new List<CategoryViewModel>();

            using (var httpClient = new HttpClient())

            {

                using (var response = await httpClient.GetAsync("http://localhost:33050/BankManager/PendingRequests"))

                {

                    var apiResponse = await response.Content.ReadAsStringAsync();

                    cat = JsonConvert.DeserializeObject<List<CategoryViewModel>>(apiResponse);

                }

            }

            return View(cat);

        }










        public async Task<IActionResult> AdsList()

        {

            

            List<Ad_Details> ADS = new List<Ad_Details>();

            using (var httpClient = new HttpClient())

            {

                using (var response = await httpClient.GetAsync("http://localhost:33050/Admin/ADDETAILS"))

                {

                    var apiResponse = await response.Content.ReadAsStringAsync();

                    ADS = JsonConvert.DeserializeObject<List<CategoryViewModel>>(apiResponse);


                }

            }

            return View(ADS);

        }

        public IActionResult Login()
        {
            return View();
        }
        public IActionResult LoginSuccess()
        {
            return View();

        }
        [HttpPost]

        public IActionResult Login(LoginViewModel Lvm)

        {

            if (ModelState.IsValid)

            {

                using (var httpClient = new HttpClient())

                {

                    StringContent content = new StringContent(JsonConvert.SerializeObject(Admin), Encoding.UTF8, "application/json");

                    using (var response = httpClient.PostAsync("http://localhost:33050/Login/LoginUser", content))

                    {

                        if (response.Result.IsSuccessStatusCode)

                        {

                            var responseText = response.Result.Content.ReadAsStringAsync().Result;

                            //ViewData["Message"] = "Valid Login Credentials";

                            return RedirectToAction("LoginSuccess", new { m = responseText });

                        }

                        else

                        {

                            ViewData["Message"] = "Check the details";

                            return RedirectToAction("Index");

                        }

                    }

                }

            }

            //return View("LoginSuccess", ViewData["Message"]);

            return View();

        }

    




         public IActionResult Details()

        {

            return View();

            

        }

        public IActionResult Index()
        {
            return View();
        }
    }
}
