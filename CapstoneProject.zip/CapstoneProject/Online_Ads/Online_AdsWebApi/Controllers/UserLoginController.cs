﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Online_AdsWebApi.Models;

namespace Online_AdsWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserLoginController : ControllerBase
    {
        AppDbContext db = null;

        public UserLoginController(AppDbContext context)

        {

            db = context;

        }

        [HttpPost]

        [Route("RegisterUser")]

        public IActionResult Register([FromBody] RegisterViewModel userobj)

        {

            if (userobj == null)

            {

                return BadRequest();

            }

            if (ModelState.IsValid)

            {

                User user = new User();


                user.UserID = userobj.UserID;
                user.Password = userobj.Password;

                user.FullName = userobj.FullName;

                user.DOB = userobj.DOB;

                user.Gender = userobj.Gender;

                user.State = userobj.State;

                user.EmailID = userobj.EmailID;

                user.PhoneNo = userobj.PhoneNo;

                db.Users.Add(user);

                db.SaveChanges();

                return Ok("User Registered Successfully");

            }

            return BadRequest("Invalid Registeration..");

        }

        [HttpPost]

        [Route("LoginUser")]

        public IActionResult Login([FromBody] LoginViewModel loginuser)

        {

            if (loginuser == null)

            {

                return BadRequest();

            }

            var user = (from u in db.Users

                        where u.EmailID == loginuser.Email && u.Password == loginuser.Password

                        select u).SingleOrDefault();

            if (user == null)

            {

                return NotFound("Invalid Login Credentials");

            }

            else

            {

                string userFullName = user.FullName;

                string message = string.Empty;

                if (user.Gender == "Male")

                {

                    message = "Mr." + userFullName;

                }

                else if (user.Gender == "Female")

                {

                    message = "Ms." + userFullName;

                }

                else

                {

                    message = userFullName;

                }

                return Ok("welcome," + message);

            }

        }

        [Route("Add Ads")]

        [HttpPost]

        public IActionResult PostAds([FromBody] Ad_Details userobj)

        {

            if (userobj == null)

            {

                return BadRequest();

            }

            if (ModelState.IsValid)

            {

                Ad_Details ad = new Ad_Details();

               // ad.AdID = userobj.AdID;

                // ad.CategoryID = userobj.CategoryID;

                ad.MainCategory = userobj.MainCategory;

                ad.SubCategory = userobj.SubCategory;

                ad.FullName = userobj.FullName;

                ad.EmailID = userobj.EmailID;

                ad.PhoneNo = userobj.PhoneNo;

                //ad.Adsstartdate = userobj.Adsstartdate;

                // ad.AdsEndDate = userobj.AdsEndDate;

                ad.Title = userobj.Title;

                ad.Description = userobj.Description;

                // ad.status = userobj.status;

                db.Ad_Details.Add(ad);

                db.SaveChanges();

                return Ok("Advertisement added Successfully");

            }

            return BadRequest("Invalid");

        }

        [Route("ModifyAds")]

        [HttpPost]

        public IActionResult ModifyAds(int id, [FromBody] Ad_Details mc)

        {

            var ad = db.Ad_Details.Find(id);

            if (ad != null)

            {

                ad.FullName = mc.FullName;

                ad.EmailID = mc.EmailID;

                ad.PhoneNo = mc.PhoneNo;

                //ad.Adsstartdate = mc.Adsstartdate;

                // ad.AdsEndDate = mc.AdsEndDate;

                ad.Title = mc.Title;

                ad.Description = mc.Description;

                db.SaveChanges();

                return Ok(ad);

            }

            var query = (from c in db.Ad_Details select c).Distinct();

            return Ok("Ad details Modified successfully");

            return Ok(ad);

        }

        [Route("AdsDetails")]

        [HttpGet]

        public IActionResult ViewAdsDetails()

        {

            var ads = db.Ad_Details.ToList();

            return Ok(ads);

        }

        [Route("DeleteAds")]

        [HttpGet]

        public IActionResult Delete(int id)

        {

            var obj = db.Ad_Details.Find(id);

            if (obj == null)

            {

                return NotFound();

            }

            else

            {

                db.Ad_Details.Remove(obj);

                db.SaveChanges();

            }

            return Ok("Category deleted Succefully");

        }

        [Route("SearchAds")]

        [HttpPost]

        public IActionResult SearchAds([FromQuery] string search)

        {

            List<Ad_Details> Ads = db.Ad_Details.Where(ad => ad.Title.Contains(search) || ad.Description.Contains(search)).ToList();

            return Ok(new { ads = Ads });

        }

        [HttpPost]

        [Route("interest")]

        public IActionResult SendInterest(int id)

        {

            return Ok();

        }

        [HttpGet]

        [Route("interestofownads")]

        public IActionResult GetInterestOfUserAds()

        {
            try

            {

                var query = (from a in db.Interests

                             where a.AdID == id

                             select a).ToList();



                return Ok(query);

            }

            catch (Exception ex)

            {

                throw ex;

            }


            return Ok();

        }

        [HttpGet]

        [Route("status")]

        public IActionResult GetStatusOfUserAds(string Status)

        {
            try

            {

                var query = (from a in db.Ad_Details

                             where a.status == Status

                             select a).ToList();

                
                return Ok(query);

            }

            catch (Exception ex)

            {

                throw ex;

            }


            return Ok();

        }

    }
}

 