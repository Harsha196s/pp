﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Online_AdsWebApi.Models;

namespace Online_AdsWebApi.Controllers
{
    [Route("controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        AppDbContext db = null;

        public AdminController(AppDbContext context)

        {

            db = context;

        }
        [Route("AddCategory")]

        [HttpPost]

        public IActionResult AddCategory([FromBody] CategoryViewModel userobj)

        {

            if (userobj == null)

            {

                return BadRequest();

            }

            if (ModelState.IsValid)

            {

                CategoryViewModel c = new CategoryViewModel();

                c.CategoryID = userobj.CategoryID;

                c.CategoryName = userobj.CategoryName;

                c.CategoryType = userobj.CategoryType;

                db.Categories.Add(c);

                db.SaveChanges();

                return Ok("Category added Successfully");

            }

            return BadRequest("Invalid");

        }
        [HttpPut]

        [Route("{id}")]

        public IActionResult ModifyCategory(int id, [FromQuery] CategoryViewModel mc)

        {

            var cat = db.Categories.Find(id);

            if (cat != null)

            {

                cat.CategoryType = mc.CategoryType;

                cat.CategoryName = mc.CategoryName;

                db.SaveChanges();

                return Ok(cat);

            }

            var query = (from c in db.Categories select c).Distinct();

            return Ok("Category Details Modified successfully");

            return Ok(cat);

        }

        [HttpDelete]

        [Route("{id}")]


        public IActionResult Delete(int id)

        {

            var obj = db.Categories.Find(id);

            if (obj == null)

            {

                return NotFound();

            }

            else

            {

                db.Categories.Remove(obj);

                db.SaveChanges();

            }

            return Ok("Category deleted Succefully");

        }

        [Route("CategoryDetails")]

        [HttpGet]

        public IActionResult ViewCategortDetails()

        {

            var details = db.Categories.ToList();

            return Ok(details);

        }

        [Route("AdsDetails")]

        [HttpGet]

        public IActionResult ViewAdsDetails()

        {

            var ads = db.Ad_Details.ToList();

            return Ok(ads);

        }

        [HttpGet]

        [Route("{id}")]

        public IActionResult SearchUser(int id)

        {

            var obj = db.Users.Find(id);

            if (obj == null)

            {

                return BadRequest();

            }

            var query = (from u in db.Users select u).Distinct();

            return Ok(query);

            //var query = (from u in db.Users where u.UserID == u.UserID select u).SingleOrDefault();

            //if(query==null)

            //{

            // return Ok("Invalid UserID");

            //}

            //else

            //{

            // return Ok(query);

            //}

        }

        [HttpGet]

        [Route("{id}")]

        public IActionResult SearchAds(int id)

        {

            var obj = db.Users.Find(id);

            if (obj == null)

            {

                return BadRequest();

            }

            var query = (from a in db.Ad_Details select a).Distinct();

            return Ok(query);

            return Ok("Ads Details");

        }
        [HttpPut]

        [Route("{id}")]

        public IActionResult ModifyStatus(int id, string AccountMod)

        {

            try

            {

                var acc = db.Ad_Details.Find(id);

                if (acc == null)

                {

                    return NotFound("No Account Found with that ID");

                }

                else

                {

                    acc.status = AccountMod;

                    db.Update(acc);

                    db.SaveChanges();

                    return Ok("Account status changed from pending to " + AccountMod);

                }

            }

            catch (Exception ex)

            {

                throw ex;

            }
        }
            [HttpPost]

            [Route("LoginAdmin")]



            public IActionResult Login([FromBody] LoginViewModel loginuser)

            {

                if (loginuser == null)

                {

                    return BadRequest();

                }

                var user = (from u in db.Users

                            where u.EmailID == loginuser.Email && u.Password == loginuser.Password

                            select u).SingleOrDefault();
                if (user == null)

                {

                    return NotFound("Invalid Login Credentials");

                }

                else

                {

                    string userFullName = user.FullName;

                    string message = string.Empty;

                    if (user.Gender == "Male")

                    {

                        message = "Mr." + userFullName;

                    }

                    else if (user.Gender == "Female")

                    {

                        message = "Ms." + userFullName;

                    }

                    else

                    {

                        message = userFullName;

                    }

                    return Ok("welcome Admin," + message);

                    //return Ok("Login Successful");

                }

            }

        }


    }  



       





    

