﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InternetBankingMVC.Models
{
    public class BankManagerDetails
    {
        
    
        public int BankManagerID { get; set; }
        [Required]
      
        public string BankManagerName { get; set; }
        [Required]
       
        public string Address { get; set; }
        [Required]
        public int PhoneNumber { get; set; }
        [Required]
  
        [DisplayName("Login ID")]
        [EmailAddress]
        public string EmailId { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [Required]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Password doesn't match!!")]
        public string ConfirmPassword { get; set; }
        [Required]
        public string PassportStatus { get; set; }
        [Required]
        
        public int BranchID { get; set; }



        //public virtual List<BranchDetails> GetBanks { get; set; }
    }
}
