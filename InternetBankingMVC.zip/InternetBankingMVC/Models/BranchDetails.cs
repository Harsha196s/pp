﻿using System.ComponentModel.DataAnnotations;

namespace InternetBankingMVC.Models
{
    public class BranchDetails
    {
        [Key]
        public int BranchID { get; set; }
        [Required]
        public string BranchName { get; set; }
        [Required]
        public string BankName { get; set; }
        [Required]
        public string State { get; set; }
        [Required]
        public string City { get; set; }
        [Required]
        public int PINCODE { get; set; }
        [Required]
        public string IFSCCode { get; set; }


       // public virtual BankManagerDetails ManagerDetails { get; set; }
    }
}
