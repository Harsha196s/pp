﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InternetBankingMVC.Models
{
    public class BeneficiaryDetails
    {
       
        public int BeneficiaryId { get; set; }
        public string BeneficiaryName { get; set; }

        public string BankName { get; set; }
        public string IFSCCode { get; set; }
        public long TransferLimit { get; set; }
   
        public int RequestId { get; set; }
    }
}
