﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InternetBankingMVC.Models
{
    public class UserRegisteration
    {
        
        public int RequestId { get; set; }
        public long SBAccountNumber { get; set; }
        //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        //public long CIFNumber { get; set; }
        public string BranchCode { get; set; }
        public long MobileNum { get; set; }

        //public virtual List<Account> GetAccounts { get; set; }
    }
}
