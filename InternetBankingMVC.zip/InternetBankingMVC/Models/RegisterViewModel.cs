﻿using System.ComponentModel.DataAnnotations;

namespace InternetBankingMVC.Models
{
    public class RegisterViewModel
    {
        public int UserID { get; set; }
        [Required]
        public string UserName { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [Compare("Password", ErrorMessage = "Password doesn't match!!")]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }
        [Required]
        public string Gender { get; set; }
        [Required]
        public int MobileNumber { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        //foreign key
        public int RoleId { get; set; }
    }
}
