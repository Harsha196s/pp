﻿using System.Text.Json.Serialization;

namespace InternetBankingMVC.Models
{
    public class StatementViewModel
    {
        public int RequestId { get; set; }
        [JsonIgnore]
        public DateTime StartDate { get; set; }
        [JsonIgnore]
        public DateTime EndDate { get; set; }
    }
}
