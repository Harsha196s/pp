﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InternetBankingMVC.Models
{
    public class Transactions
    {
     
        public int TransactionID { get; set; }
        public DateTime TransactionDate { get; set; }
        public long Amount { get; set; }

  
        public int BeneficiaryId { get; set; }

        public string BeneficiaryName { get; set; }


        public int RequestId { get; set; }
    }
}
