﻿namespace InternetBankingMVC.Models
{
    public class AccountViewModel
    {
        public int RequestId { get; set; }
    }
}
