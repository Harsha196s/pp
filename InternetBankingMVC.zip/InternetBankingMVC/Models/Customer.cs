﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InternetBankingMVC.Models
{
    public class Customer
    {
        
        [EmailAddress]
        public string LoginID { get; set; }
 
        public string CustomerName { get; set; }
       
        [DataType(DataType.Password)]
        public string Password { get; set; }


        [ForeignKey("RequestId")]
        public int RequestId { get; set; }

    }
}
