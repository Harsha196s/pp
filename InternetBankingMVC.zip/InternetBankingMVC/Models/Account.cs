﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InternetBankingMVC.Models
{
    public class Account
    {
    
        public long SBAccountNumber { get; set; }
        //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        //public long CIFNumber { get; set; }

        public string BranchCode { get; set; }
        public string AccountType { get; set; }
        public long Balance { get; set; }
        public DateTime AccountStartDate { get; set; }
        [Required]
        public string AccountStatus { get; set; }

        //public virtual UserRegisteration RegisteredUser { get; set; }


  
        [Required]
        public int RequestId { get; set; }

    }
}
