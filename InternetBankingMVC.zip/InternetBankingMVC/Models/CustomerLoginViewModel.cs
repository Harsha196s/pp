﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InternetBankingMVC.Models
{
    public class CustomerLoginViewModel
    {
        [Key]
        [EmailAddress]
        public string LoginID { get; set; }


        [DataType(DataType.Password)]
        public string Password { get; set; }


    }
}
