﻿namespace InternetBankingMVC.Models
{
    public class BranchViewModel
    {
        public int BranchID { get; set; }
    }
}
