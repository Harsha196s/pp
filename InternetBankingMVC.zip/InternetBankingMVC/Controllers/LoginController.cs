﻿using InternetBankingMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Text;

namespace InternetBankingMVC.Controllers
{
    public class LoginController : Controller
    {
        [BindProperty]
        public LoginViewModel LoginUser { get; set; }
        [BindProperty]
        public RegisterViewModel RegisterUser { get; set; }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Register()
        {
            return View();
        }
        public IActionResult RegisterSuccess()
        {
           
            return View();
        }
    
        [HttpPost]
        public IActionResult Register(RegisterViewModel Rvm)
        {
            if (ModelState.IsValid)
            {

                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonConvert.SerializeObject(RegisterUser), Encoding.UTF8, "application/json");
                    using (var response = httpClient.PostAsync("http://localhost:33050/Login/RegisterUser", content))
                    {
                        if (response.Result.IsSuccessStatusCode)
                        {
                            //var responseText = response.Result.Content.ReadAsStringAsync().Result;
                            return RedirectToAction("RegisterSuccess");
                        }
                        else
                        {
                            ViewData["Message"] = "Invalid Registration";
                        }
                    }
                }



            }
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }
        
        public IActionResult LoginSuccess(string m)
        {
            // return View();
            ViewData["Message"] = m;
            return View();
        }
        //public IActionResult LoginSuccess()
        //{
        //    return View();
        //}
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel Lvm)
        {
            
                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonConvert.SerializeObject(LoginUser), Encoding.UTF8, "application/json");
                    using (var response = await httpClient.PostAsync("http://localhost:33050/Login/LoginAdmin", content))
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            if((Lvm.UserName=="John Kelvin" && Lvm.Password=="Kelvin@123")||
                            (Lvm.UserName == "Priya" && Lvm.Password == "Priya@123"))
                            {-
                            return RedirectToAction("Index", "BankManager");
                            }
                            else if(Lvm.UserName == "Admin" && Lvm.Password == "Admin@123")
                            {
                            return RedirectToAction("ManagerList", "Admin");
                            }
                            else
                            {
                                return RedirectToAction("Index", "Customer");
                            }
                           
                            
                        }
                        else
                        {
                            ViewData["Message"] = "Check the details";
                            return RedirectToAction("Index");
                        }
                    }
                }

           

            //return View("LoginSuccess", ViewData["Message"]);
            return View();

        }
    }
}
