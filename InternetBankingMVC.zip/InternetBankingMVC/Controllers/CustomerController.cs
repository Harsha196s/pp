﻿using InternetBankingMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;

namespace InternetBankingMVC.Controllers
{
    public class CustomerController : Controller
    {
        [BindProperty]
        public UserRegisteration userObj { get; set; }
        [BindProperty]
        public Account accObj { get; set; }
        [BindProperty]
        public Customer cusObj { get; set; }
        [BindProperty]
        public CustomerLoginViewModel cuslog { get; set; }
        [BindProperty]
        public BeneficiaryDetails benObj { get; set; }
        [BindProperty]
        public Transactions Tobj { get; set; }

        public IActionResult Index()
        {
            return View();
        }
        
        public IActionResult RegisterUser()
        {
            return View();
        }
        public IActionResult AddAccount()
        {
            return View();
        }
        public IActionResult AccountAdded(string m)
        {
            ViewData["Message"] = m;
            return View();
        }
        
        [HttpPost]
        public async Task<IActionResult> AddAccount(Account accDetails)
        {

            using (var httpClient = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(accObj), Encoding.UTF8, "application/json");
                using (var response = await httpClient.PostAsync("http://localhost:33050/Customer/RegisteredUserAccount", content))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        var responseText = response.Content.ReadAsStringAsync().Result;

                        return RedirectToAction("AccountAdded", new { m = responseText });
                    }
                    else
                    {
                        ViewData["Message"] = "Not Added To The List";
                    }
                }
            }



            return View();
        }

        //CheckStatus
        public IActionResult CheckStatus()
        {
            return View();

        }

        [HttpPost]
        public async Task<IActionResult> CheckStatus(int RequestId, long MobileNum)
        {
            string account = null;
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:33050/Customer/StatusTracking/" + RequestId + "?phNo=" + MobileNum))
                {

                    var apiResponse = await response.Content.ReadAsStringAsync();
                    account = (apiResponse);
                }
            }
            ViewData["Message"] = account;
            return View();
        }


        public IActionResult CreateLogin()
        {
            return View();
        }
        public IActionResult LoginCreated(string m)
        {
            ViewData["Message"] = m;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateLogin(Customer cusDetails)
        {

            using (var httpClient = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(cusObj), Encoding.UTF8, "application/json");
                using (var response = await httpClient.PostAsync("http://localhost:33050/Customer/CreateLogin", content))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        var responseText = response.Content.ReadAsStringAsync().Result;

                        return RedirectToAction("LoginCreated", new { m = responseText });
                    }
                    else
                    {
                        ViewData["Message"] = "Not Added To The List";
                    }
                }
            }



            return View();
        }
        public IActionResult CustomerLogin()
        {
            return View();
        }
      
        public IActionResult CustomerLoginSuccess(string m)
        {
     
            ViewData["Message"] = m;
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> CustomerLogin(CustomerLoginViewModel Lvm)
        {
           
                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonConvert.SerializeObject(cusObj), Encoding.UTF8, "application/json");
                    using (var response = await httpClient.PostAsync("http://localhost:33050/Customer/LoginCustomer", content))
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            var responseText = response.Content.ReadAsStringAsync().Result;
                            //ViewData["Message"] = "Valid Login Credentials";
                            return RedirectToAction("CustomerLoginSuccess", new { m=responseText});
                        }
                        else
                        {
                            ViewData["Message"] = "Check the details";
                  
                        }
                    }
                }

            

     
            return View();

        }

        public IActionResult RegisteredUser(string m)
        {
            ViewData["Message"] = m;
            return View();
        }
        [BindProperty]
        public UserRegisteration usrobj { get; set; }
        [HttpPost]
        public async Task<IActionResult> RegisterUser(UserRegisteration usrDetails)
        {
      
            
                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonConvert.SerializeObject(usrobj), Encoding.UTF8, "application/json");
                    using (var response = await httpClient.PostAsync("http://localhost:33050/Customer/NewUserRegistration",content))
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            var responseText = response.Content.ReadAsStringAsync().Result;

                            return RedirectToAction("RegisteredUser", new { m = responseText });
                        }
                        else
                        {
                            ViewData["Message"] = "Not Added To The List";
                        }
                    }
                }



            return View();
        }

        public IActionResult AddBeneficiary()
        {

            return View();
        }
        public IActionResult TransferFund()
        {

            return View();
        }
        public IActionResult PaymentStatus(string m)
        {
            ViewData["Message"] = m;
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> TransferFund(Transactions transaction)
        {
            using (var httpClient = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(Tobj), Encoding.UTF8, "application/json");
                using (var response = await httpClient.PostAsync("http://localhost:33050/Customer/FundTransfer", content))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        var responseText = response.Content.ReadAsStringAsync().Result;

                        return RedirectToAction("PaymentStatus", new { m = responseText });
                    }
                    else
                    {
                        ViewData["Message"] = "Not Added To The List";
                    }
                }
            }

            return View();
        }



        public IActionResult BeneficiaryAdded(string m)
        {
            ViewData["Message"] = m;
            return View();
        }
 
        [HttpPost]
        public async Task<IActionResult> AddBeneficiary(BeneficiaryDetails benfDetails)
        {
            
                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonConvert.SerializeObject(benObj), Encoding.UTF8, "application/json");
                    using (var response = await httpClient.PostAsync("http://localhost:33050/Customer/AddBeneficiary", content))
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            var responseText = response.Content.ReadAsStringAsync().Result;

                            return RedirectToAction("BeneficiaryAdded", new { m = responseText });
                        }
                        else
                        {
                            ViewData["Message"] = "Not Added To The List";
                        }
                    }
                }

            return View();
        }




        public IActionResult ViewStatementOfId(StatementViewModel svm)
        {
            return View();
        }
        public IActionResult ViewStatement()
        {
            return View();
        }
        [HttpPost]

        public async Task<IActionResult> ViewStatement(StatementViewModel svm)
        {
            
            Transactions transaction = null;
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:33050/Customer/ViewStatement/"+svm.RequestId + "?StartDate=" + svm.StartDate+ "?EndDate="+ svm.EndDate))
                {
                    var apiResponse = await response.Content.ReadAsStringAsync();
                    transaction = JsonConvert.DeserializeObject<Transactions>(apiResponse);
                }

            }
            return View(transaction);

        }
        

        public IActionResult ViewAccountOfId(AccountViewModel avm)
        {
            return View();
        }
        public IActionResult GetAccountDetails(AccountViewModel avm)
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> GetAccountDetails(int RequestId)
        {
            Account acc = null;
            //List<BranchDetails> Branch = new List<BranchDetails>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:33050/Customer/" + RequestId))
                {
                    var apiResponse = await response.Content.ReadAsStringAsync();
                    acc = JsonConvert.DeserializeObject<Account>(apiResponse);
                }

            }
            return View(acc);
        }



    }


}

