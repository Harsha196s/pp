﻿using InternetBankingMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;
using System.Collections.Generic;
using System.Text.Json;

namespace InternetBankingMVC.Controllers
{
    public class AdminController : Controller
    {
       
        [BindProperty]
        public BankManagerDetails MgrDetails { get; set; }

       
        public async Task<IActionResult> ManagerList()
        {
            // List<BankManagerDetails> managerDetails = new List<BankManagerDetails>();
            List<BankManagerDetails> Managers = new List<BankManagerDetails>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:33050/Admin/ManagersList"))
                {
                    var apiResponse=await response.Content.ReadAsStringAsync();
                    Managers = JsonConvert.DeserializeObject<List<BankManagerDetails>>(apiResponse);
                }

            }
            return View(Managers);
            
        }

        
        public IActionResult AddManager()
        {
            
            return View();
        }
        public IActionResult ManagerAdded(string m)
        {
            ViewData["Message"] = m;
            return View();
        }
        public IActionResult ManagerDeleted(string m)
        {
            ViewData["Message"] = m;
            return View();
        }
        public IActionResult ManagerModified(string m)
        {
            ViewData["Message"] = m;
            return View();
        }
        public IActionResult Details(BranchViewModel bvm)
        {

            return View();

        }
        public IActionResult BranchDetails(BranchViewModel bvm)
        {
         
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> BranchDetails(int BranchID)
        {
            BranchDetails Branch = null;
            //List<BranchDetails> Branch = new List<BranchDetails>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:33050/Admin/"+ BranchID))
                {
                    var apiResponse = await response.Content.ReadAsStringAsync();
                    Branch = JsonConvert.DeserializeObject<BranchDetails>(apiResponse);
                }

            }
            return View(Branch);
        }
        public IActionResult DeleteManager()
        {
            return View();
        }
        public IActionResult ModifyManager()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> DeleteManager(int id)
        {
            if (ModelState.IsValid)
            {

                using (var httpClient = new HttpClient())
                {
                    //StringContent content = new StringContent(JsonConvert.SerializeObject(MgrDetails), Encoding.UTF8, "application/json");

                    using (var response = await httpClient.DeleteAsync("http://localhost:33050/Admin/" + id))
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            var responseText = response.Content.ReadAsStringAsync().Result;

                            return RedirectToAction("ManagerDeleted", new { m = responseText });
                        }
                        else
                        {
                            ViewData["Message"] = "Not Added To The List";
                        }
                    }
                }



            }
            return View();
            //return View();
        }

        [HttpPost]
        public async Task<IActionResult> ModifyManager(int BankManagerID)
        {
            if (ModelState.IsValid)
            {

                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonConvert.SerializeObject(MgrDetails), Encoding.UTF8, "application/json");
                   
                    using (var response = await httpClient.PostAsync("http://localhost:33050/Admin/"+ BankManagerID, content))
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            var responseText = response.Content.ReadAsStringAsync().Result;

                            return RedirectToAction("ManagerModified", new { m = responseText });
                        }
                        else
                        {
                            ViewData["Message"] = "Not Added To The List";
                        }
                    }
                }



            }
            return View();
            //return View();
        }
        
        [HttpPost]
        public IActionResult AddManager(BankManagerDetails bmDetails)
        {
            //ModelState.Remove("GetBanks");
            if (ModelState.IsValid)
            {

                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonConvert.SerializeObject(MgrDetails), Encoding.UTF8, "application/json");
                    using (var response = httpClient.PostAsync("http://localhost:33050/Admin/AddManager", content))
                    {
                        if (response.Result.IsSuccessStatusCode)
                        {
                            var responseText = response.Result.Content.ReadAsStringAsync().Result;
                            
                            return RedirectToAction("ManagerAdded",new { m = responseText });
                        }
                        else
                        {
                            ViewData["Message"] = "Not Added To The List";
                        }
                    }
                }



            }
            return View();
        }
    }
}
