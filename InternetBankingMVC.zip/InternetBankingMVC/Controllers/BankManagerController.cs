﻿using InternetBankingMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;

namespace InternetBankingMVC.Controllers
{
    public class BankManagerController : Controller
    {
        [BindProperty]
        public Account accObj { get; set; }
        public IActionResult Index()
        {
            return View();
        }
        public async Task<IActionResult> ViewPendingAccounts()
        {
            List<Account> pendingUser = new List<Account>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:33050/BankManager/PendingRequests"))
                {
                    var apiResponse = await response.Content.ReadAsStringAsync();
                    pendingUser = JsonConvert.DeserializeObject<List<Account>>(apiResponse);
                }
            }
                return View(pendingUser);
        }
        public async Task<IActionResult> ViewRejectedAccounts()
        {
            List<Account> RejUser = new List<Account>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:33050/BankManager/Rejected"))
                {
                    var apiResponse = await response.Content.ReadAsStringAsync();
                    RejUser = JsonConvert.DeserializeObject<List<Account>>(apiResponse);
                }
            }
            return View(RejUser);
        }
        public async Task<IActionResult> ViewApprovedAccounts()
        {
            List<Account> AppUser = new List<Account>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:33050/BankManager/Approved"))
                {
                    var apiResponse = await response.Content.ReadAsStringAsync();
                    AppUser = JsonConvert.DeserializeObject<List<Account>>(apiResponse);
                }
            }
            return View(AppUser);
        }

        


        public IActionResult StatusChanged(string m)
        {
            ViewData["Message"] = m;
            return View();
        }
        public IActionResult ModifyStatus()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> ModifyStatus(int RequestId)
        {
            
  
            using (var httpClient = new HttpClient())
            {
                    StringContent content = new StringContent(JsonConvert.SerializeObject(accObj), Encoding.UTF8, "application/json");

                    using (var response = await httpClient.PutAsync("http://localhost:33050/BankManager/ModifyStatus/" + RequestId + "?AccountMod=" + accObj.AccountStatus, content))
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            var responseText = response.Content.ReadAsStringAsync().Result;

                            return RedirectToAction("StatusChanged", new { m = responseText });
                        }
                        else
                        {
                            ViewData["Message"] = "Not Added To The List";
                        }
                    }
            }



            
            //return View();
            return View();
        }
    }
}
