﻿using Login_WebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Login_WebAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class BankManagerController : ControllerBase
    {
        AppDbContext db = null;
        public BankManagerController(AppDbContext context)
        {
            db = context;
        }
     
        [HttpGet]
        [Route("PendingRequests")]
        public IActionResult ViewPendingRequets()
        {
            //branch code,ifsc,state,city,pincode
            try
            {

                //var prevAccStatus = "Pending";
                var query = (from a in db.Accounts
                             where a.AccountStatus == "Pending"
                             select a).ToList();
                //var user = db.Accounts.Find(AccStatus=="Pending");
                return Ok(query);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
   

        [HttpPut]
        [Route("ModifyStatus/{id}")]
        public IActionResult ModifyStatus(int id, string AccountMod)
        {
            try
            {
                var acc=db.Accounts.Find(id);
                if (acc==null)
                {
                    return NotFound("No Account Found with that ID");
                }
                else
                {
                    acc.AccountStatus = AccountMod;
                    db.Update(acc);
                    db.SaveChanges();
                    return Ok("Account status changed from pending to " + AccountMod);
                }

               
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        [HttpGet]
        [Route("{Status}")]
        public IActionResult ViewAllAppRej(string Status)
        {

            try
            {
                
                var query = (from a in db.Accounts
                             where a.AccountStatus == Status
                             select a).ToList();
                //var user = db.Accounts.Find(AccStatus=="Pending");
                return Ok(query);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

    }
}
