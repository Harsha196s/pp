﻿using Login_WebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Login_WebAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        AppDbContext db = null;
        public AdminController(AppDbContext context)
        {
            db = context;
        }
        [HttpPost]
        [Route("AddManager")]
        public IActionResult AddManager([FromBody] BankManagerDetails entityAdd)
        {
            try
            {
                db.BankManagers.Add(entityAdd);
                db.SaveChanges();
                return Ok("Added To The Managers Table");
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        [Route("ManagersList")]
        public IActionResult GetManagerList()
        {
            return Ok(db.BankManagers.ToList());
        }
        //<a asp-action="AddAccount">Add Account Details</a>
        [HttpPut]
        [Route("{id}")]
        public IActionResult ModifyBMDetails(int id, [FromQuery] BankManagerDetails entityModified)
        {
            try
            {
                var BM = db.BankManagers.Find(id);
                BM.BankManagerName=entityModified.BankManagerName;
                BM.BranchID = entityModified.BranchID;
                BM.Address = entityModified.Address;
                BM.PhoneNumber = entityModified.PhoneNumber;
                BM.PassportStatus = entityModified.PassportStatus;
                BM.Password = entityModified.Password;
                BM.EmailId = entityModified.EmailId;
                BM.ConfirmPassword = entityModified.ConfirmPassword;

                db.Update(BM);
                db.SaveChanges();
                return Ok("Updated..");
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        [HttpDelete]
        [Route("{id}")]
        public IActionResult DeleteManager(int id)
        {
            try
            {
                var BM = db.BankManagers.Find(id);
                if (BM != null)
                {
                    db.BankManagers.Remove(BM);
                    db.SaveChanges();
                }
                return Ok("Deleted");
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpGet]
        [Route("{id}")]
        public IActionResult GetBranchById(int id)
        {
            //branch code,ifsc,state,city,pincode
            try
            {
                var branch = db.Branches.Find(id);
                return Ok(branch);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

    }
}
