﻿using Login_WebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Login_WebAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        AppDbContext db = null;
        public LoginController(AppDbContext context)
        {
            db = context;
        }
        [HttpPost]
        [Route("RegisterUser")]
        public IActionResult Register([FromBody] RegisterViewModel userobj)
        {
            if (userobj == null)
            {
                return BadRequest();
            }

            if (ModelState.IsValid)
            {
                User user = new User();
                user.UserID = userobj.UserID;
                user.UserName = userobj.UserName;
                user.Password = userobj.Password;
                user.RoleId = userobj.RoleId;
                user.MobileNumber = userobj.MobileNumber;
                user.Gender = userobj.Gender;
                user.Email = userobj.Email;

                db.Users.Add(user);
                db.SaveChanges();
                return Ok("User Registered Successfully");
            }
            return BadRequest("Invalid Registeration..");
        }
        
        [HttpPost]
        [Route("LoginAdmin")]
        //ADMIN
        public IActionResult Login([FromBody] LoginViewModel loginuser)
        {
            if (loginuser == null)
            {
                return BadRequest();
            }
            var user = (from u in db.Users 
                        where u.UserName == loginuser.UserName && u.Password == loginuser.Password
                        select u).SingleOrDefault();
            if (user == null)
            {
                return NotFound("Invalid Login Credentials");
            }
            else
            {
                string userFullName = user.UserName;
                string message = string.Empty;
                if (user.Gender == "Male")
                {
                    message = "Mr." + userFullName;
                }
                else if (user.Gender == "Female")
                {
                    message = "Ms." + userFullName;
                }
                else
                {
                    message = userFullName;
                }
                return Ok("welcome Admin," + message);
                //return Ok("Login Successful");

            }

        }
    }
}
