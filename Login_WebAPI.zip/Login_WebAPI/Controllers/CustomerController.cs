﻿using Login_WebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Login_WebAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        AppDbContext db = null;
        public CustomerController(AppDbContext context)
        {
            db = context;
        }
        [HttpPost]
        [Route("NewUserRegistration")]
        public IActionResult AddCustomer([FromBody] UserRegisteration entityAdd)
            //, [FromQuery] Account AccountEntity)
        {

            try
            {
                db.RegisteredUsers.Add(entityAdd);
                //db.Accounts.Add(AccountEntity);
                db.SaveChanges();
                //AccountStatus
                return Ok("Your Registration is done.Track the Account Status by using " +
                    "Your RequestId : " + entityAdd.RequestId+ " (Remember For Further Use.)");
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpPost]
        [Route("RegisteredUserAccount")]
        public IActionResult AddCustomerAccount([FromBody] Account AccountEntity)
        //, [FromQuery] Account AccountEntity)
        {

            try
            {
                db.Accounts.Add(AccountEntity);

                var sbAccCheck = (from r in db.RegisteredUsers join a in db.Accounts on
                                  r.RequestId equals a.RequestId
                                  where r.RequestId==AccountEntity.RequestId
                                  select r).ToList();
             
                if (sbAccCheck == null)
                {
                    return Ok("No Account Matched");
                }
                else
                {
                   
                    //db.Accounts.Add(AccountEntity);
                    db.SaveChanges();
                    //AccountStatus
                    return Ok("Account Added.Track the status and create login creadentials after approval.");
                }
                
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        [Route("StatusTracking/{id}")]
        public IActionResult ViewTracking(int id, long phNo)
        {
            var query = (from a in db.Accounts join r in db.RegisteredUsers
                         on a.RequestId equals r.RequestId
                         where a.RequestId==id && r.MobileNum==phNo
                         select a.AccountStatus).SingleOrDefault();
            return Ok(query);
        }
        [HttpPost]
        [Route("CreateLogin")]
        public IActionResult CreateLogin([FromBody] Customer customerentity)
        {

            try
            {
                
                var query = (from a in db.Accounts
                             where a.AccountStatus=="Pending" && a.RequestId==customerentity.RequestId
                             select a.RequestId);
                if(query!=null)
                {
                    return Ok("Your Account Status is still in Pending");
                }
                else
                {
                    db.Customers.Add(customerentity);

                    db.SaveChanges();

                    return Ok("Login Credentials are Updated.Make payment through Internet Banking");
                }
               
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpPost]
        [Route("LoginCustomer")]
        //ADMIN
        public IActionResult Login([FromBody] CustomerLoginViewModel cuslogin)
        {
            if (cuslogin == null)
            {
                return BadRequest();
            }
            var user = (from u in db.Customers
                        where u.LoginID == cuslogin.LoginID && u.Password == cuslogin.Password
                        select u).SingleOrDefault();
            if (user == null)
            {
                return NotFound("Invalid Login Credentials");
            }
            else
            {
                return Ok("welcome Customer");
                //return Ok("Login Successful");

            }

        }





        [HttpGet]
        [Route("{id}")]
        public IActionResult GetAccountByReqId(int id)
        {
            try
            {
                
                    var acc = db.Accounts.Find(id);
                    return Ok(acc);
                
               
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
       

        [HttpPost]
        [Route("AddBeneficiary")]
        public IActionResult AddBeneficiary([FromBody] BeneficiaryDetails entityAdd)
        {

            try
            {
                var query = (from a in db.Accounts
                             where a.AccountStatus == "Pending" && a.RequestId == entityAdd.RequestId
                             select a.RequestId);
                if (query == null)
                {
                    return Ok("Your Account Status is still in Pending");
                }
                else
                {
                    db.Beneficiaries.Add(entityAdd);
                    //db.Accounts.Add(AccountEntity);
                    db.SaveChanges();
                    //AccountStatus
                    return Ok("Beneficiary Details are Added");
                }
                
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpPost]
        [Route("FundTransfer")]
        public IActionResult TransferFunds([FromBody] Transactions entityAdd)
        {
            try
            {
                var query = (from t in db.Beneficiaries
                             where t.RequestId==entityAdd.RequestId
                             select t).ToList();
                
                var bal = (from a in db.Accounts
                    where a.RequestId==entityAdd.RequestId
                    select a.Balance).SingleOrDefault();

                var limit = (from b in db.Beneficiaries
                             where b.BeneficiaryId==entityAdd.BeneficiaryId
                             select b.TransferLimit).SingleOrDefault();
               long RemBal = bal - entityAdd.Amount;

                //if(entityAdd.Amount>)

                if (query==null)
                {
                    return Ok("No Beneficiary Account Matched With the details");
                }
                else if(limit < entityAdd.Amount)
                {
                    return Ok("Transfer Limit Exceeded.");
                }
                else
                {
                    
                    db.FundTransactions.Add(entityAdd);
           
                    //db.SaveChanges();
                    var acc = db.Accounts.Find(entityAdd.RequestId);
                    acc.Balance = RemBal;
                    db.Update(acc);
                    db.SaveChanges();

                    return Ok("Payment Done and Your Account Balance is now " + " " + RemBal);
                }
               
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        [Route("ViewStatement/{id}")]
        public IActionResult ViewStatement(int id,DateTime StartDate,DateTime EndDate)
        {
            try
            {
                //requestID
                //var acc = db.Accounts.Find(id);
                var query = (from ft in db.FundTransactions join acc in db.Accounts
                             on ft.RequestId equals acc.RequestId
                             where  ft.TransactionDate >= StartDate && ft.TransactionDate <= EndDate && ft.RequestId==id
                             select ft).ToList();
                return Ok(query);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
