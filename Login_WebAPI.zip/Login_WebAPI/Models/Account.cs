﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Login_WebAPI.Models
{
    public class Account
    {
        [Key]
        public int AccountId { get; set; }
        [ForeignKey("SBAccountNumber")]
        public long SBAccountNumber { get; set; }
        
        [DisplayName("IFSCCode")]
        public string BranchCode { get; set; }
        public string AccountType { get; set; }
        public long Balance { get; set; }
        public DateTime AccountStartDate { get; set; }
        public string AccountStatus { get; set; }

       // public virtual UserRegisteration RegisteredUser { get; set; }


        [ForeignKey("RequestId")]
        public int RequestId { get; set; }

    }
}
