﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Login_WebAPI.Models
{
    public class User
    {
        [Key]
       public int UserID { get; set; }
        
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Gender { get; set; }
        public int MobileNumber { get; set; }
        public string Email { get; set; }
        //foreign key
        public int RoleId { get; set; }
        [ForeignKey("RoleId")]
        public virtual Role Role { get; set; }
        
    }
}
