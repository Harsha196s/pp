﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Login_WebAPI.Models
{
    public class Transactions
    {
        [Key]
        public int TransactionID { get; set; }
        public DateTime TransactionDate { get; set; }
        public long Amount { get; set; }

        [ForeignKey("BeneficiaryId")]
        public int BeneficiaryId { get; set; }

        public string BeneficiaryName { get; set; }

        [ForeignKey("RequestId")]
        public int RequestId { get; set; }
    }
}
