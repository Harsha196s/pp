﻿
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Login_WebAPI.Models
{
    public class BeneficiaryDetails
    {
        [Key]
        public int BeneficiaryId { get; set; }
        public string BeneficiaryName { get; set; }

        public string BankName { get; set; }
        public string IFSCCode { get; set; }
        public long TransferLimit { get; set; }
        [ForeignKey("RequestId")]
        public int RequestId { get; set; }
    }
}
