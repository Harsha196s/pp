﻿using System.ComponentModel.DataAnnotations;

namespace Login_WebAPI.Models
{
    public class RegisterViewModel
    {
        public int UserID { get; set; }

        public string UserName { get; set; }
        public string Password { get; set; }
        [Compare("Password", ErrorMessage = "Password doesn't match!!")]
        public string ConfirmPassword { get; set; }
        public string Gender { get; set; }
        public int MobileNumber { get; set; }
        public string Email { get; set; }
        //foreign key
        public int RoleId { get; set; }
    }
}
