﻿using Microsoft.EntityFrameworkCore;
namespace Login_WebAPI.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<Role> Roles { get; set; }
        public virtual DbSet<Account> Accounts { get; set; }
        public virtual DbSet<BankManagerDetails> BankManagers { get; set; }
        public virtual DbSet<BeneficiaryDetails> Beneficiaries { get; set; }
        public virtual DbSet<BranchDetails> Branches { get; set; }
        public virtual DbSet<Customer> Customers { get; set; }
        public virtual DbSet<Transactions> FundTransactions { get; set; }
        public virtual DbSet<UserRegisteration> RegisteredUsers { get; set; }

    }

}
