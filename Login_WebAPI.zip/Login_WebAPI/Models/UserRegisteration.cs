﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Login_WebAPI.Models
{
    public class UserRegisteration
    {
        [Key]
        public int RequestId { get; set; }
        public long SBAccountNumber { get; set; }
       // [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
       // public long CIFNumber { get; set; }
        public string BranchCode { get; set; }
        public long MobileNum { get; set; }

       // public virtual List<Account> GetAccounts { get; set; }
    }
}
