﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Web_Api.Models;

namespace Web_Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StockController : ControllerBase
    {

        AppDbContext db = null;
        public StockController(AppDbContext context)
        {

            db = context;

        }
        [HttpPost]
        [Route("AddStockDetails")]
        public IActionResult AddManager([FromBody] PMS__UserStockMap entityAdd)
        {
            try
            {
                db.UserStockDetails.Add(entityAdd);
                db.SaveChanges();
                return Ok("Added To The stockdetails Table");
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpPost]
        [Route("AddStockMaster")]
        public IActionResult AddStockMaster([FromBody] PMS_StockMaster entityAdd)
        {
            try
            {
                db.StockMasters.Add(entityAdd);
                db.SaveChanges();
                return Ok("Added To The stockdetails Table"+entityAdd.StockID);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpPost]
        [Route("AddDailyStockDetails")]
        public IActionResult AddDaily([FromBody] PMS_DailyStockPrice entityAdd)
        {
            try
            {
                db.DailyStockPrizes.Add(entityAdd);
                db.SaveChanges();
                return Ok("Added To The stockdetails Table");
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        [Route("{id}")]
        //login id
        public IActionResult GetStockById(int id)
        {
            //branch code,ifsc,state,city,pincode
            try
            {
                //var sname = (from r in db.StockMasters
                //                  join a in db.UserStockDetails on
                //                  r.StockID equals a.StockID
                //                  where a.LoginID == id
                //                  select r.StockName).ToList();
                var stock= (from r in db.StockMasters
                            join a in db.UserStockDetails on
                            r.StockID equals a.StockID
                            where a.LoginID == id
                            select a).ToList();
               // var sm = db.UserStockDetails.Find(id);
                return Ok(stock);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpPut]
        [Route("{id}")]
        public IActionResult ModifyStockDetails(int id, [FromQuery] PMS__UserStockMap entityModified)
        {
            try
            {
                var BM = db.UserStockDetails.Find(id);

                BM.Quantity = entityModified.Quantity;
                BM.PurchaseDate = entityModified.PurchaseDate;
                BM.PurchasePrize = entityModified.PurchasePrize;
               

                db.Update(BM);
                db.SaveChanges();
                return Ok("Updated..");
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
    }
}
