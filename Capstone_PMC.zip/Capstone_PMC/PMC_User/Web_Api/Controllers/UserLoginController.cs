﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Web_Api.Models;

namespace Web_Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserLoginController : ControllerBase
    {
        AppDbContext db = null;

        public UserLoginController(AppDbContext context)

        {

            db = context;

        }
          [HttpPost]
        [Route("RegisterUser")]
        public IActionResult Register([FromBody] RegisterViewModel userobj)
        {
            if (userobj == null)
            {
                return BadRequest();
            }

                if (ModelState.IsValid)
            {
                UserRegistration user = new UserRegistration();
                user.LoginID = userobj.LoginID;
                user.First_Name = userobj.First_Name;
                user.Last_Name = userobj.Last_Name;
                user.Password = userobj.Password;
               user.ConfirmPassword = userobj.ConfirmPassword;
                user.Address = userobj.Address;
                user.Email = userobj.Email;
                user.ContactNo = userobj.ContactNo;
                user.Income = userobj.Income;
                user.CurrentEmployer = userobj.CurrentEmployer;



                db.UserRegistration.Add(user);
                db.SaveChanges();
                return Ok("User Registered Successfully");
            }
            return BadRequest("Invalid Registeration..");
        }
        
        [HttpPost]
        [Route("Login")]
        //ADMIN
        public IActionResult Login([FromBody] LoginViewModel loginuser)
        {
            if (loginuser == null)
            {
                return BadRequest();
            }
            var user = (from u in db.UserRegistration
                        where u.Email == loginuser.Email && u.Password == loginuser.Password
                        select u).SingleOrDefault();
            if (user == null)
            {
                return NotFound("Invalid Login Credentials");
            }
            else
            {
                return Ok("Login Successful");

            }

        }
    }
        /*
         * ================================add
           [HttpPost]
        [Route("AddManager")]
        public IActionResult AddManager([FromBody] BankManagerDetails entityAdd)
        {
            try
            {
                db.BankManagers.Add(entityAdd);
                db.SaveChanges();
                return Ok("Added To The Managers Table");
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        ============================================View
         [HttpGet]
        [Route("{id}")]
        //login id
        public IActionResult GetBranchById(int id)
        {
            //branch code,ifsc,state,city,pincode
            try
            {
                var branch = db.Branches.Find(id);
                return Ok(branch);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        ===========================Modify
         [HttpPut]
        [Route("{id}")]
        public IActionResult ModifyBMDetails(int id, [FromQuery] BankManagerDetails entityModified)
        {
            try
            {
                var BM = db.BankManagers.Find(id);
                BM.BankManagerName=entityModified.BankManagerName;
                BM.BranchID = entityModified.BranchID;
                BM.Address = entityModified.Address;
                BM.PhoneNumber = entityModified.PhoneNumber;
                BM.PassportStatus = entityModified.PassportStatus;
                BM.Password = entityModified.Password;
                BM.EmailId = entityModified.EmailId;
                BM.ConfirmPassword = entityModified.ConfirmPassword;

                db.Update(BM);
                db.SaveChanges();
                return Ok("Updated..");
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
         */

    }

