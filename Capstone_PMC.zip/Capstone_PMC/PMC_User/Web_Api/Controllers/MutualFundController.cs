﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Web_Api.Models;

namespace Web_Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MutualFundController : ControllerBase
    {
        AppDbContext db = null;
        public MutualFundController(AppDbContext context)
        {

            db = context;

        }
        [HttpPost]
        [Route("AddMFDetails")]
        public IActionResult AddMF([FromBody] PMS_UserMFMap entityAdd)
        {
            try
            {
                db.UserMFDetails.Add(entityAdd);
                db.SaveChanges();
                return Ok("Added To The MutualFunddetails Table");
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpPost]
        [Route("AddMFMasterDetails")]
        public IActionResult AddfundMaster([FromBody] PMS_MutualFundMaster entityAdd)
        {
            try
            {
                db.FundMasters.Add(entityAdd);
                db.SaveChanges();
                return Ok("Added To The MutualFunddetails Table");
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpPost]
        [Route("AddMFDailyDetails")]
        public IActionResult AdfMFNAV([FromBody] PMS_DailyMFNAV entityAdd)
        {
            try
            {
                db.MutualFundsNAV.Add(entityAdd);
                db.SaveChanges();
                return Ok("Added To The MutualFunddetails Table");
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpGet]
        [Route("{id}")]
        //login id
        public IActionResult GetLoginById(int id)
        {
            //branch code,ifsc,state,city,pincode
            try
            {
                var stock = (from r in db.FundMasters
                             join a in db.UserMFDetails on
                             r.MFID equals a.MFID
                             where a.LoginID == id
                             select a).ToList();
                // var sm = db.UserStockDetails.Find(id);
                return Ok(stock);
              
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpPut]
        [Route("{id}")]
        public IActionResult ModifyMFDetails(int id, [FromQuery] PMS_UserMFMap entityModified)
        {
            try
            {
                var BM = db.UserMFDetails.Find(id);
                BM.Quantity = entityModified.Quantity;
                BM.PurchaseDate = entityModified.PurchaseDate;
                BM.PurchaseQty = entityModified.PurchaseQty;


                db.Update(BM);
                db.SaveChanges();
                return Ok("Updated..");
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
    }
}
