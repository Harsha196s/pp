﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Web_Api.Models;

namespace Web_Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FixedIncomeController : ControllerBase
    {

        AppDbContext db = null;
        public FixedIncomeController(AppDbContext context)
        {

            db = context;

        }
        [HttpPost]
        [Route("AddFixedIncomeDetails")]
        public IActionResult AddFixedIncome([FromBody] PMS_UserFixedMap entityAdd)
        {
            try
            {
                db.UserFixedIncome.Add(entityAdd);
                db.SaveChanges();
                return Ok("Added To The FixedIncomedetails Table");
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpPost]
        [Route("AddFixedIncomeMasterDetails")]
        public IActionResult AddFixedIncome([FromBody] PMS_FixedIncomeMaster entityAdd)
        {
            try
            {
                db.FixedIncomeMasters.Add(entityAdd);
                db.SaveChanges();
                return Ok("Added To The FixedIncomedetails Table");
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpGet]
        [Route("{id}")]
        //login id
        public IActionResult GetLoginById(int id)
        {
            //branch code,ifsc,state,city,pincode
            try
            {
                var stock = (from r in db.FixedIncomeMasters
                             join a in db.UserFixedIncome on
                             r.FIID equals a.FIID
                             where a.LoginID == id
                             select a).ToList();
                // var sm = db.UserStockDetails.Find(id);
                return Ok(stock);
               
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpPut]
        [Route("{id}")]
        public IActionResult ModifyFixedIncomeDetails(int id, [FromQuery] PMS_UserFixedMap entityModified)
        {
            try
            {
                var BM = db.UserMFDetails.Find(id);
                
                BM.PurchaseDate = entityModified.PurchaseDate;
                BM.PurchaseQty = entityModified.PurchaseQty;


                db.Update(BM);
                db.SaveChanges();
                return Ok("Updated..");
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
    }
}
