﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Web_Api.Models
{
    public class PMS_DailyMFNAV
    {
        [Key]
        public int DailyMFNAVId { get; set; }
        [ForeignKey("MFID")]
        public int MFID  { get; set; }

        public  DateTime Date { get; set; }

        public int ClosingPrice { get; set; }
    }
}
