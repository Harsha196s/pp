﻿using Microsoft.EntityFrameworkCore;

namespace Web_Api.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)

        {


        }

      public virtual DbSet<UserRegistration> UserRegistration { get; set; }
        public virtual DbSet<PMS__UserStockMap> UserStockDetails { get; set; }
        public virtual DbSet<PMS_UserMFMap> UserMFDetails { get; set; }
        public virtual DbSet<PMS_UserFixedMap> UserFixedIncome { get; set; }
        public virtual DbSet<PMS_StockMaster> StockMasters{ get; set; }


        public virtual DbSet<PMS_MutualFundMaster> FundMasters { get; set; }

        public virtual DbSet<PMS_FixedIncomeMaster> FixedIncomeMasters { get; set; }
        public virtual DbSet<PMS_DailyMFNAV> MutualFundsNAV { get; set; }

        public virtual DbSet<PMS_DailyStockPrice> DailyStockPrizes { get; set; }

        public virtual DbSet<PMS_User> User { get; set; }









    }
}
