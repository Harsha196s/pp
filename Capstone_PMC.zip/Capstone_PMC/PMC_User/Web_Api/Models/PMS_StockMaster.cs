﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Web_Api.Models
{
    public class PMS_StockMaster
    {
        [Key]
       
        public int StockID { get; set; }
        public string StockName { get; set; }
        public float FaceValue { get; set; }
    }
}
