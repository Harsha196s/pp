﻿using System.ComponentModel.DataAnnotations;

namespace Web_Api.Models
{
    public class UserRegistration
    {
        [Key]
        public int LoginID { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }

        public long ContactNo { get; set; }

        public  int Income { get; set; } 
        public string CurrentEmployer { get; set; }
    }
}
