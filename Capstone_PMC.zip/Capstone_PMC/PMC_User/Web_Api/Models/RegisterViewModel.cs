﻿using System.ComponentModel.DataAnnotations;

namespace Web_Api.Models
{
    public class RegisterViewModel
    {
        
        [Required]
        public int LoginID { get; set; }
        [Required]
        public string First_Name { get; set; }
        [Required]
        public string Last_Name { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        public string ConfirmPassword { get; set; }
        public string Address { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]

        public long ContactNo { get; set; }
        [Required]

        public int Income { get; set; }
        [Required]
        public string CurrentEmployer { get; set; }
    }
}
