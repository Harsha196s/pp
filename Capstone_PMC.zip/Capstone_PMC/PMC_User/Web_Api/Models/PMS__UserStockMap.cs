﻿using Microsoft.EntityFrameworkCore.SqlServer.Query.Internal;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Web_Api.Models
{
    public class PMS__UserStockMap
    {

        [ForeignKey("StockID")]
        public int StockID { get; set; }
        [Key]
        public int TranscationNo { get; set; }
        [ForeignKey("LoginID")]
        public int LoginID { get; set; }

        public float Quantity { get; set; }


        public DateTime PurchaseDate { get; set; }

        public float PurchasePrize { get; set; }
       

    }
}
