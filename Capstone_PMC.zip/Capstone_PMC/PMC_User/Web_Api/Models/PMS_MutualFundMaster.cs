﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Web_Api.Models
{
    public class PMS_MutualFundMaster
    {

        [Key]
     
        public int MFID { get; set; }
        public string MFName { get; set; }
        public string  FundHouse { get; set; }

        public string  FundType { get; set; }
        public int FaceValue { get; set; }

        
    }
}
