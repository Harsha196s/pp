﻿using System.ComponentModel.DataAnnotations;

namespace Web_Api.Models
{
    public class PMS_User
    {
        [Key]
        public int LoginID { get; set; }
        public string Password { get; set; }
        public string EmailID { get; set; }

        public DateTime DOB{ get; set; }

        public string First_Name{ get; set; }
   
        public string Last_Name{ get; set; }
        public int Gender{ get; set; }

        public string Address{ get; set; }

        public string State{ get; set; }
        public string City{ get; set; }
        public long  PinCode{ get; set; }
        public long Phone{ get; set; }

        public bool AdminIndicator { get; set; }

        public bool ValidUserIndicator { get; set; }



    }
}
