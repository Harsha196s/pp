﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Web_Api.Models
{
    public class PMS_UserMFMap
    {
        [Key]
        public int MFTransactionNo { get; set; }

        [ForeignKey("MFID")]
        public int MFID { get; set; }

        [ForeignKey("LoginID")]
        public int LoginID { get; set; }

        public int Quantity { get; set; }
        public DateTime PurchaseDate { get; set; }
        public int PurchaseQty { get; set; }

        public int FolioNo { get; set; }

    }

}
