﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Web_Api.Models
{
    public class PMS_UserFixedMap
    {
        [Key]
        public int FITransactionNo { get; set; }
        [ForeignKey("FIID")]
        public int FIID { get; set; }

        [ForeignKey("LoginID")]
        public int LoginID { get; set; }

        public DateTime PurchaseDate { get; set; }
        public int PurchaseQty { get; set; }
    }
}
