﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Web_Api.Models
{
    public class PMS_FixedIncomeMaster
    {
       
        [Key]
        
        public int FIID { get; set; }

        public string FIName { get; set; }

        public string FIDescription { get; set; }

        public int RateOfInterest { get; set; }

        public int Tenure { get; set; }

        public int PurchaseUnitValue { get; set; }

    }
}
