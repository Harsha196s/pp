﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Web_Api.Models
{
    public class PMS_DailyStockPrice
    {
        [Key]
        public int DailyStockPrice { get; set; }

        [ForeignKey("StockID")]
        public int StockID { get; set; }
        public DateTime Date { get; set; }
        public float  ClosingPrice { get; set; }
       

    }
}
