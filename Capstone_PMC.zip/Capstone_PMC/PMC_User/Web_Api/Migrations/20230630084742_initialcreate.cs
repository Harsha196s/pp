﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Web_Api.Migrations
{
    public partial class initialcreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "DailyStockPrizes",
                columns: table => new
                {
                    DailyStockPrice = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StockID = table.Column<int>(type: "int", nullable: false),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ClosingPrice = table.Column<float>(type: "real", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DailyStockPrizes", x => x.DailyStockPrice);
                });

            migrationBuilder.CreateTable(
                name: "FixedIncomeMasters",
                columns: table => new
                {
                    FIID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FIName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FIDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RateOfInterest = table.Column<int>(type: "int", nullable: false),
                    Tenure = table.Column<int>(type: "int", nullable: false),
                    PurchaseUnitValue = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FixedIncomeMasters", x => x.FIID);
                });

            migrationBuilder.CreateTable(
                name: "FundMasters",
                columns: table => new
                {
                    MFID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MFName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FundHouse = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FundType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FaceValue = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FundMasters", x => x.MFID);
                });

            migrationBuilder.CreateTable(
                name: "MutualFundsNAV",
                columns: table => new
                {
                    DailyMFNAVId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MFID = table.Column<int>(type: "int", nullable: false),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ClosingPrice = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MutualFundsNAV", x => x.DailyMFNAVId);
                });

            migrationBuilder.CreateTable(
                name: "StockMasters",
                columns: table => new
                {
                    StockID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StockName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FaceValue = table.Column<float>(type: "real", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StockMasters", x => x.StockID);
                });

            migrationBuilder.CreateTable(
                name: "UserFixedIncome",
                columns: table => new
                {
                    FITransactionNo = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FIID = table.Column<int>(type: "int", nullable: false),
                    LoginID = table.Column<int>(type: "int", nullable: false),
                    PurchaseDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PurchaseQty = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserFixedIncome", x => x.FITransactionNo);
                });

            migrationBuilder.CreateTable(
                name: "UserMFDetails",
                columns: table => new
                {
                    MFTransactionNo = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MFID = table.Column<int>(type: "int", nullable: false),
                    LoginID = table.Column<int>(type: "int", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    PurchaseDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PurchaseQty = table.Column<int>(type: "int", nullable: false),
                    FolioNo = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserMFDetails", x => x.MFTransactionNo);
                });

            migrationBuilder.CreateTable(
                name: "UserRegistration",
                columns: table => new
                {
                    LoginID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    First_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Last_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ConfirmPassword = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ContactNo = table.Column<long>(type: "bigint", nullable: false),
                    Income = table.Column<int>(type: "int", nullable: false),
                    CurrentEmployer = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserRegistration", x => x.LoginID);
                });

            migrationBuilder.CreateTable(
                name: "UserStockDetails",
                columns: table => new
                {
                    TranscationNo = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StockID = table.Column<int>(type: "int", nullable: false),
                    LoginID = table.Column<int>(type: "int", nullable: false),
                    Quantity = table.Column<float>(type: "real", nullable: false),
                    PurchaseDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PurchasePrize = table.Column<float>(type: "real", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserStockDetails", x => x.TranscationNo);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DailyStockPrizes");

            migrationBuilder.DropTable(
                name: "FixedIncomeMasters");

            migrationBuilder.DropTable(
                name: "FundMasters");

            migrationBuilder.DropTable(
                name: "MutualFundsNAV");

            migrationBuilder.DropTable(
                name: "StockMasters");

            migrationBuilder.DropTable(
                name: "UserFixedIncome");

            migrationBuilder.DropTable(
                name: "UserMFDetails");

            migrationBuilder.DropTable(
                name: "UserRegistration");

            migrationBuilder.DropTable(
                name: "UserStockDetails");
        }
    }
}
